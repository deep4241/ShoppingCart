
import { Col, Row, Button } from 'antd';
import React , { useState }  from 'react';
import { faPlus, faMinus, faRupeeSign } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

function CartPage(props) {
  const [amount, setAmount] = useState([]);
  const items = props.items;
  const removeCart = props.removeCart;
  return (
    
    <div className="site-layout-content" style={{ marginTop: '10px' }}>
      <Row type="flex" gutter={8}>
      {props.items.map((post,i) =>(
        <Col xs={24} xl={18} key ={i}>
          <Row type="flex" className='cartcard'>
            <Col xs={6} xl={2}><img alt='' src={post.image} width={50} /></Col>
            <Col xs={18} xl={10} className='cartcarddesc'>
            <h2>{post.name}</h2>
              <p className='price'><FontAwesomeIcon icon={faRupeeSign}/>{post.price.actual} </p>
            </Col>
            <Col xs={12} xl={6} className='cartcardplusminus'>
              <div><Button type="primary" shape="circle"><FontAwesomeIcon icon={faPlus} /> </Button> </div>
              <div> 1</div>
              <div><Button type="primary" shape="circle"><FontAwesomeIcon icon={faMinus} /> </Button> </div>
            </Col>
            <Col xs={12} xl={6} className='cartcardremove'><a onClick={() => removeCart(post)}>Remove</a></Col>
          </Row>
        </Col>
  ))}


        <Col xs={24} xl={6}>
          <Row type="flex" style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Col xs={24} xl={22}>
              <div className='cartSidebar'>
                <h2>Price Details</h2>
                <ul>
                  <li>Price ({items.length} item): </li>
                  <li>{amount}</li>
                </ul>
                <ul className='sidebarBg'>
                  <li>Total Payable :</li>
                  <li>{amount}</li>
                </ul>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}
export default CartPage;