
import React, { Col, Row } from 'react';
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import CartIcon from './CartIcon';
import Search from './Search';
import Layout, { Header } from 'antd/lib/layout/layout';

function CustHeader() {

  return (  
    <Layout>
    <Layout.Header>
        <Row type="flex" gutter={8}>
          <Col xs={12} xl={4}>
            <FontAwesomeIcon className='headerLogo' icon={faStar} />
          </Col>
          <Col xs={12} xl={20}>
            <div className='nav'>
              <a href=''><Search /></a>
              <a href=''><CartIcon /></a>
            </div>
          </Col>
        </Row>

      </Layout.Header>
      </Layout>
  );
}
export default CustHeader;