
import { Layout, Col, Row, Input } from 'antd';
import React , { useState, useEffect }  from 'react';
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import CartIcon from './modules/common/component/CartIcon';
import Search from './modules/common/component/Search';
import CartPage from './modules/cartpage/CartPage';
import HomePage from './modules/homepage/HomePage';
import { Route, Switch, Link } from 'react-router-dom';
import axios from 'axios';
import 'antd/dist/antd.css';
import './assets/css/style.css';
const { Header, Content, Footer } = Layout;

function App(props) {
  const [cart, setCart] = useState([]);
  const [items, setPosts] = useState([]);
  const [prod, setProd] = useState();


  const addToCart = (items) =>{
    setCart([...cart, {...items, qty:1}]);
    //console.log(cart);  
  };
  const removeCart = (productRemove) =>{
    setCart(
      cart.filter((item) => item.name != productRemove.name)
    );
   
  };
  
   const inputEvent = (event) =>{
      const prod = event.target.value;
      cart.filter((item) => item.cart != event.cart)
      console.log(prod);
      setProd(prod);
      setPosts(
        items.filter((item) => item.name.indexOf(prod) >= 0)
      );
  };
  // const hideShow = () =>{
  //   setShow(true);
   
  // };
  const sort = ( mode = 'pricehigh') => {
    items.sort( (a,b) => {      
      if( mode === 'pricehigh'){
        return b.price.actual - a.price.actual;
      } else if( mode === 'pricelow'){
        return a.price.actual - b.price.actual;
      } else if( mode === 'discounthigh')  {
        return b.discount - a.discount;
      } 
    });
    setPosts(items);
  }
  useEffect((props) =>{
    axios.get('https://my-json-server.typicode.com/prograk/demo/items')
    .then( res =>{
      //console.log(res)
      setPosts(res.data)
    })
    .catch( err =>{
      console.log(err)
    })
 },[])
  return (
    <Layout className="layout">
            <Header>
        <Row type="flex" gutter={8}>
          <Col xs={12} xl={4}>
          <Link to="/homepage"> <FontAwesomeIcon className='headerLogo' icon={faStar} /></Link>
           
          </Col>
          <Col xs={12} xl={20}>
            <div className='nav'>

             <Search addToCart = {addToCart} inputEvent = {inputEvent}/>
              <Link to="/cartpage"><CartIcon count = {cart.length} /></Link>
            </div>
          </Col>
        </Row>

      </Header>
      <Content style={{ padding: '0 20px', marginBottom: '50px' }}> 

           <Switch>
            <Route exact path='/homepage' component={() => <HomePage addToCart = {addToCart} items = {items} sort = {sort}/>}/>
            <Route exact path='/cartpage' component={() => <CartPage items = {cart} removeCart = {removeCart} />}/>
           </Switch>
     
      </Content>
      <Footer style={{ textAlign: 'center' }}> © copyright</Footer>
    </Layout>
  );
}
export default App;